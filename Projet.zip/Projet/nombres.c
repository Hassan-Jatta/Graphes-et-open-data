#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


// Plusieurs algorithmes sur les nombres

// 1. Calcul de la factorielle (itérative)
unsigned long long factorielleIterative(int n) {
    unsigned long long resultat = 1;
    for (int i = 1; i <= n; i++) {
        resultat *= i;
    }
    return resultat;
}

// 2. Calcul de la factorielle (récursive)
unsigned long long factorielleRecursive(int n) {
    if (n == 0 || n == 1)
        return 1;
    return n * factorielleRecursive(n - 1);
}

// 3. Somme des chiffres d'un nombre
int sommeChiffres(int n) {
    int somme = 0;
    while (n != 0) {
        somme += n % 10; // Extraire le dernier chiffre
        n /= 10;         // Supprimer le dernier chiffre
    }
    return somme;
}

// 4. Vérification de primalité (optimisée)
int estPremier(int n) {
    if (n <= 1) return 0; // 0 et 1 ne sont pas premiers
    if (n <= 3) return 1; // 2 et 3 sont premiers
    if (n % 2 == 0 || n % 3 == 0) return 0;

    for (int i = 5; i <= sqrt(n); i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return 0;
    }
    return 1;
}

// 5. Crible d'Ératosthène (pour trouver les nombres premiers jusqu'à N)
void cribleEratosthene(int n) {
    bool estPremier[n + 1];
    for (int i = 0; i <= n; i++) estPremier[i] = true;

    for (int p = 2; p * p <= n; p++) {
        if (estPremier[p]) {
            for (int i = p * p; i <= n; i += p) {
                estPremier[i] = false;
            }
        }
    }

    printf("Nombres premiers jusqu'à %d :\n", n);
    for (int i = 2; i <= n; i++) {
        if (estPremier[i]) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

// 6. Calcul du PGCD (Algorithme d'Euclide)
int pgcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// 7. Calcul du PPCM (Plus Petit Commun Multiple)
int ppcm(int a, int b) {
    return (a / pgcd(a, b)) * b; // Division avant multiplication pour éviter l'overflow
}

// 8. Exponentiation rapide (Fast Exponentiation)
long long exponentiationRapide(int base, int expo) {
    long long resultat = 1;
    while (expo > 0) {
        if (expo % 2 == 1) { // Si expo est impair
            resultat *= base;
        }
        base *= base;
        expo /= 2;
    }
    return resultat;
}

// 9. Conversion d'un nombre décimal en binaire
void decimalVersBinaire(int n) {
    int binaire[32];
    int i = 0;

    while (n > 0) {
        binaire[i] = n % 2;
        n /= 2;
        i++;
    }

    printf("Binaire : ");
    for (int j = i - 1; j >= 0; j--) {
        printf("%d", binaire[j]);
    }
    printf("\n");
}

// 10. Conversion d'un nombre binaire en décimal
int binaireVersDecimal(int binaire) {
    int decimal = 0, i = 0;

    while (binaire > 0) {
        int dernierBit = binaire % 10;
        decimal += dernierBit * pow(2, i);
        binaire /= 10;
        i++;
    }
    return decimal;
}








