#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


// 1. Tri à bulle (version 1)

void triBulle(int tab[], int taille) {
    for (int i = 0; i < taille - 1; i++) {
        for (int j = 0; j < taille - 1; j++) {
            if (tab[j] > tab[j+1]) {
                int tmp = tab[j];
                tab[j] = tab[j+1];
                tab[j+1] = tmp;
            }
        }
    }
}

// 2. Tri à bulle (version 2)

void triBulle2(int tab[], int taille) {
    for (int i = 0; i < taille - 1; i++) {
        for (int j = 0; j < taille - i - 2; j++) {
            if (tab[j] > tab[j+1]) {
                int tmp = tab[j];
                tab[j] = tab[j+1];
                tab[j+1] = tmp;
            }
        }
    }
}

// 3. Tri à bulle optimisé (version 3)


void triBulleOpti(int tab[], int taille){
    
    int i =0;
    bool continuer = true;
    while (i < taille-1 && continuer == true){
        continuer = false;
        for (int j = 0; j < taille - i - 2; j++){
            if (tab[j] > tab[j+1]){
                int tmp = tab[j];
                tab[j] = tab[j+1];
                tab[j+1] = tmp;
                continuer = true;
            }
        }
    }
}


// 4. Tri cocktail 

void triCocktail(int tab[], int taille){
    bool echange = true;
    int debut = 0;
    int fin = taille-2;
    while (echange == true){
        echange = false;
        for (int i = debut; i<fin; i++){
            if (tab[i] > tab[i+1]){
                int tmp = tab[i];
                tab[i] = tab[i+1];
                tab[i+1] = tmp;
                echange = true;
            }
        }
        fin = fin-1;
        for (int i = fin; i>debut; i--){
            if (tab[i] < tab[i-1]){
                int tmp = tab[i];
                tab[i] = tab[i-1];
                tab[i-1] = tmp;
                echange = true;
            }
        }
        debut = debut+1;
    }
}

// 5. Tri cocktail optimisé


void triCocktailOptimise(int arr[], int n) {
    int debut = 0, fin = n - 1;
    bool echange = true;

    while (debut < fin) {
        echange = false;

        // Balayage gauche → droite
        for (int i = debut; i < fin; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                echange = true;
            }
        }
        if (!echange) break; // Arrêter si aucune permutation
        fin--;

        echange = false;

        // Balayage droite → gauche
        for (int i = fin; i > debut; i--) {
            if (arr[i] < arr[i - 1]) {
                int temp = arr[i];
                arr[i] = arr[i - 1];
                arr[i - 1] = temp;
                echange = true;
            }
        }
        if (!echange) break; // Arrêter si aucune permutation
        debut++;
    }
}

// 6. Tri cocktail décroissant

void triCocktailDecroissant(int arr[], int n) {
    bool echange = true;
    int debut = 0, fin = n - 1;

    while (echange) {
        echange = false;

        // Balayage gauche → droite (max en premier)
        for (int i = debut; i < fin; i++) {
            if (arr[i] < arr[i + 1]) { // Inversion de la condition
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                echange = true;
            }
        }
        fin--;

        // Balayage droite → gauche
        for (int i = fin; i > debut; i--) {
            if (arr[i] > arr[i - 1]) { // Inversion de la condition
                int temp = arr[i];
                arr[i] = arr[i - 1];
                arr[i - 1] = temp;
                echange = true;
            }
        }
        debut++;
    }
}


// 7. Tri cocktail avec étapes

void afficherTableau(int arr[], int n) {
    for (int i = 0; i < n; i++) printf("%d ", arr[i]);
    printf("\n");
}

void triCocktailAvecEtapes(int arr[], int n) {
    int debut = 0, fin = n - 1;
    bool echange = true;

    while (debut < fin) {
        echange = false;

        // Balayage gauche → droite
        for (int i = debut; i < fin; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                echange = true;
            }
        }
        printf("Après balayage gauche → droite : ");
        afficherTableau(arr, n);
        fin--;

        // Balayage droite → gauche
        for (int i = fin; i > debut; i--) {
            if (arr[i] < arr[i - 1]) {
                int temp = arr[i];
                arr[i] = arr[i - 1];
                arr[i - 1] = temp;
                echange = true;
            }
        }
        printf("Après balayage droite → gauche : ");
        afficherTableau(arr, n);
        debut++;
    }
}


// 8. Tri par selection 

void triSelection(int tab[], int taille){
    for (int i = 0; i<taille-2; i++){
        int min = i;
        for (int j = i+1; j<taille-1; j++){
            if (tab[j] < tab[min]){
                min = j;
            }
        }
        if (i != min){
            int tmp = tab[i];
            tab[i] = tab[min];
            tab[min] = tmp;
        }
    }
}

// 9. Tri par selection optimisé

void triSelectionOptimise(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        int echange = 0;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
                echange = 1; // Un échange potentiel a été détecté
            }
        }
        if (echange) {
            int temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        } else {
            break; // Arrêter si le tableau est déjà trié
        }
    }
}


// 10. Tri par selection récursif


void triSelectionRecursif(int arr[], int n, int debut) {
    if (debut >= n - 1) return; // Condition d'arrêt

    int minIndex = debut;
    for (int i = debut + 1; i < n; i++) {
        if (arr[i] < arr[minIndex]) {
            minIndex = i;
        }
    }
    // Échange des éléments
    int temp = arr[debut];
    arr[debut] = arr[minIndex];
    arr[minIndex] = temp;

    // Appel récursif pour le reste du tableau
    triSelectionRecursif(arr, n, debut + 1);
}

// 11. Tri par selection avec étapes

void triSelectionEtapeParEtape(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // Échange des éléments
        int temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;

        // Affiche le tableau après chaque étape
        printf("Étape %d: ", i + 1);
        for (int k = 0; k < n; k++) {
            printf("%d ", arr[k]);
        }
        printf("\n");
    }
}


void triSelectionBidirectionnel(int arr[], int n) {
    int debut = 0, fin = n - 1;

    while (debut < fin) {
        int minIndex = debut, maxIndex = debut;

        for (int i = debut; i <= fin; i++) {
            if (arr[i] < arr[minIndex]) minIndex = i;
            if (arr[i] > arr[maxIndex]) maxIndex = i;
        }

        // Échange du plus petit élément avec l'élément de début
        int temp = arr[debut];
        arr[debut] = arr[minIndex];
        arr[minIndex] = temp;

        // Ajuste l'indice du maximum si l'échange a affecté l'index
        if (maxIndex == debut) maxIndex = minIndex;

        // Échange du plus grand élément avec l'élément de fin
        temp = arr[fin];
        arr[fin] = arr[maxIndex];
        arr[maxIndex] = temp;

        debut++;
        fin--;
    }
}

// 12. Tri par selection avec pointeurs

void triSelectionPointeurs(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        int *min = arr + i;
        for (int *j = arr + i + 1; j < arr + n; j++) {
            if (*j < *min) {
                min = j;
            }
        }
        // Échange des valeurs
        int temp = *(arr + i);
        *(arr + i) = *min;
        *min = temp;
    }
}

// 13. Tri par selection des éléments négatifs

void triSelectionNegatifs(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] >= 0) continue; // Ignore les éléments positifs
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex] && arr[j] < 0) {
                minIndex = j;
            }
        }
        // Échange des éléments
        int temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}



// 14. Tri par insertion

void triInsertion(int tab[], int taille){
    for (int i = 1; i<taille-1; i++){
        int x = tab[i];
        int j = i;
        while (j>0 && tab[j-1] > x){
            tab[j] = tab[j-1];
            j = j-1;
        }
        tab[j] = x;
    }
}



// 15. Tri par insertion décroissant

void triInsertionDecroissant(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int cle = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] < cle) { // Inversion de la condition
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = cle;
    }
}

// 16. Tri par insertion avec étapes

void triInsertionEtapeParEtape(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int cle = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > cle) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = cle;

        // Affiche l'état du tableau après chaque insertion
        printf("Étape %d: ", i);
        for (int k = 0; k < n; k++) printf("%d ", arr[k]);
        printf("\n");
    }
}


// 17. Tri par insertion des éléments négatifs


void triInsertionNegatifs(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        if (arr[i] < 0) { // Ne traiter que les nombres négatifs
            int cle = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > cle && arr[j] < 0) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = cle;
        }
    }
}


// 18. Tri par insertion récursif

void triInsertionRecursif(int arr[], int n) {
    if (n <= 1) return; // Condition d'arrêt

    // Tri du sous-tableau
    triInsertionRecursif(arr, n - 1);

    int cle = arr[n - 1];
    int j = n - 2;

    while (j >= 0 && arr[j] > cle) {
        arr[j + 1] = arr[j];
        j--;
    }
    arr[j + 1] = cle;
}

// 19. Tri par insertion avec pointeurs

void triInsertionPointeurs(int *arr, int n) {
    for (int i = 1; i < n; i++) {
        int cle = *(arr + i);
        int *j = arr + i - 1;

        while (j >= arr && *j > cle) {
            *(j + 1) = *j;
            j--;
        }
        *(j + 1) = cle;
    }
}


// 20. Tri par insertion des éléments négatifs avec pointeurs

int maximum(int tab[], int debut, int fin) {
    if (fin-debut < 0) return -1;
    int i_max = debut;
    for (int i = debut+1; i <= fin; i++) {
        if (tab[i_max] < tab[i]) {
            i_max = i;
        }
    }
    return tab[i_max];
}

void triComptage(int tab[], int taille){
    int max = maximum(tab, 0, taille-1);
    int x = 0;
    int* comptage = (int*) malloc(sizeof(int) * (max+1));

    for (int i = 0; i <= max; i++) {
        comptage[i] = 0;
    }


    for (int i = 0; i<taille; i++){
        comptage[tab[i]] = comptage[tab[i]] + 1;
    }
    for (int i = 0; i<=max; i++){
        for (int j = 0; j<comptage[i]; j++){
            tab[x] = i;
            x = x+1; 
        }
    }

    free(comptage);
}

// 21. Tri par comptage


void triDénombrementEtapeParEtape(int arr[], int n) {
    int max = arr[0];
    for (int i = 1; i < n; i++) if (arr[i] > max) max = arr[i];

    int *count = (int *)calloc(max + 1, sizeof(int));

    // Compter les occurrences
    for (int i = 0; i < n; i++) count[arr[i]]++;

    // Reconstruire le tableau trié avec affichage
    int index = 0;
    for (int i = 0; i <= max; i++) {
        while (count[i] > 0) {
            arr[index++] = i;
            count[i]--;
        }
        printf("Étape %d: ", i);
        for (int k = 0; k < n; k++) printf("%d ", arr[k]);
        printf("\n");
    }

    free(count);
}


// 22. Tri par comptage des éléments négatifs


void triDénombrementNegatifs(int arr[], int n) {
    // Trouver la valeur minimale et maximale
    int min = arr[0], max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) max = arr[i];
        if (arr[i] < min) min = arr[i];
    }

    int range = max - min + 1;

    // Initialiser le tableau de comptage
    int *count = (int *)calloc(range, sizeof(int));

    // Compter les occurrences en tenant compte de l'offset min
    for (int i = 0; i < n; i++) {
        count[arr[i] - min]++;
    }

    // Reconstruire le tableau trié
    int index = 0;
    for (int i = 0; i < range; i++) {
        while (count[i] > 0) {
            arr[index++] = i + min;
            count[i]--;
        }
    }

    // Libérer la mémoire allouée
    free(count);
}


// 23. Tri par comptage avec pointeurs

void fusion(int* L, int* T1, int taille1, int* T2, int taille2) {
    int i = 0, j = 0, k = 0;

    while (i < taille1 && j < taille2) {
        if (T1[i] <= T2[j]) {
            L[k++] = T1[i++];
        } else {
            L[k++] = T2[j++];
        }
    }

    while (i < taille1) {
        L[k++] = T1[i++];
    }

    while (j < taille2) {
        L[k++] = T2[j++];
    }
}



void triFusion(int* L, int n) {
    if (n <= 1) return;
    
    int milieu = n / 2;

    int* T1 = (int*)malloc(milieu * sizeof(int));
    int* T2 = (int*)malloc((n - milieu) * sizeof(int));

    for (int i = 0; i < milieu; i++) {
        T1[i] = L[i];
    }
    for (int i = milieu; i < n; i++) {
        T2[i - milieu] = L[i];
    }

    triFusion(T1, milieu);
    triFusion(T2, n - milieu);

    fusion(L, T1, milieu, T2, n - milieu);

    free(T1);
    free(T2);
}


// 24. Tri fusion décroissant

void fusionDecroissant(int arr[], int gauche, int milieu, int droite) {
    int i, j, k;
    int n1 = milieu - gauche + 1;
    int n2 = droite - milieu;

    int L[n1], R[n2];

    for (i = 0; i < n1; i++) L[i] = arr[gauche + i];
    for (j = 0; j < n2; j++) R[j] = arr[milieu + 1 + j];

    i = 0; j = 0; k = gauche;

    while (i < n1 && j < n2) {
        if (L[i] >= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }

    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

void triFusionDecroissant(int arr[], int gauche, int droite) {
    if (gauche < droite) {
        int milieu = gauche + (droite - gauche) / 2;

        triFusionDecroissant(arr, gauche, milieu);
        triFusionDecroissant(arr, milieu + 1, droite);

        fusionDecroissant(arr, gauche, milieu, droite);
    }
}


// 25. Tri fusion avec étapes

void fusionAvecAffichage(int arr[], int gauche, int milieu, int droite) {
    int i, j, k;
    int n1 = milieu - gauche + 1;
    int n2 = droite - milieu;

    int L[n1], R[n2];

    for (i = 0; i < n1; i++) L[i] = arr[gauche + i];
    for (j = 0; j < n2; j++) R[j] = arr[milieu + 1 + j];

    i = 0; j = 0; k = gauche;

    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }

    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    // Afficher le tableau après chaque fusion
    printf("Fusion [%d-%d]: ", gauche, droite);
    for (int x = gauche; x <= droite; x++) printf("%d ", arr[x]);
    printf("\n");
}

void triFusionAvecAffichage(int arr[], int gauche, int droite) {
    if (gauche < droite) {
        int milieu = gauche + (droite - gauche) / 2;

        triFusionAvecAffichage(arr, gauche, milieu);
        triFusionAvecAffichage(arr, milieu + 1, droite);

        fusionAvecAffichage(arr, gauche, milieu, droite);
    }
}