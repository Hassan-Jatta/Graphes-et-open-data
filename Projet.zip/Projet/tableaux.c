#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Plusieurs algorithmes sur les tableaux

// 1. Rotation d'un tableau (rotation à droite)
void rotationTableau(int tableau[], int taille, int positions) {
    positions = positions % taille; // Réduire le nombre de rotations inutiles
    int temp[positions];
    
    // Copier les éléments à déplacer
    for (int i = 0; i < positions; i++) {
        temp[i] = tableau[taille - positions + i];
    }

    // Décaler les éléments
    for (int i = taille - 1; i >= positions; i--) {
        tableau[i] = tableau[i - positions];
    }

    // Placer les éléments copiés dans leur nouvelle position
    for (int i = 0; i < positions; i++) {
        tableau[i] = temp[i];
    }
}

// 2. Suppression d'un élément dans un tableau
void suppressionElement(int tableau[], int *taille, int element) {
    int i;
    for (i = 0; i < *taille; i++) {
        if (tableau[i] == element) {
            break;
        }
    }
    
    if (i == *taille) {
        printf("Élément non trouvé\n");
        return;
    }
    
    // Décaler les éléments pour combler l'espace vide
    for (int j = i; j < *taille - 1; j++) {
        tableau[j] = tableau[j + 1];
    }
    
    (*taille)--; // Réduire la taille du tableau
}

// 3. Inversion d'un tableau
void inversionTableau(int tableau[], int taille) {
    int temp;
    for (int i = 0; i < taille / 2; i++) {
        temp = tableau[i];
        tableau[i] = tableau[taille - 1 - i];
        tableau[taille - 1 - i] = temp;
    }
}

// 4. Fusion de deux tableaux triés
void fusionTableauxTries(int tableau1[], int taille1, int tableau2[], int taille2, int tableauFusion[]) {
    int i = 0, j = 0, k = 0;

    // Fusionner les deux tableaux triés
    while (i < taille1 && j < taille2) {
        if (tableau1[i] < tableau2[j]) {
            tableauFusion[k++] = tableau1[i++];
        } else {
            tableauFusion[k++] = tableau2[j++];
        }
    }

    // Ajouter les éléments restants de tableau1
    while (i < taille1) {
        tableauFusion[k++] = tableau1[i++];
    }

    // Ajouter les éléments restants de tableau2
    while (j < taille2) {
        tableauFusion[k++] = tableau2[j++];
    }
}

// 5. Somme maximale d'une sous-séquence (Algorithme de Kadane)
int sommeMaxSousSequence(int tableau[], int taille) {
    int maxCourant = tableau[0];
    int maxGlobal = tableau[0];

    for (int i = 1; i < taille; i++) {
        maxCourant = (tableau[i] > maxCourant + tableau[i]) ? tableau[i] : maxCourant + tableau[i];
        if (maxCourant > maxGlobal) {
            maxGlobal = maxCourant;
        }
    }
    return maxGlobal;
}