import argparse
import csv
import os
import sqlite3
import tempfile
import clang.cindex
from clang.cindex import CursorKind, TypeKind
from tqdm import tqdm

# Définir le chemin vers la bibliothèque libclang
clang.cindex.Config.set_library_path('/opt/homebrew/opt/llvm@16/lib/libclang.dylib')

def analyse_code_c(filepath):
    """
    Analyse un fichier C et récupère diverses métriques des fonctions définies.
    """
    index = clang.cindex.Index.create()
    tu = index.parse(filepath, args=['-std=c11', '-I/usr/include'])
    
    resultats = {}

    def compter_boucles(node, niveau=0, compteur=None):
        if compteur is None:
            compteur = {"simple": 0, "double": 0, "triple": 0}

        for enfant in node.get_children():
            if enfant.kind in [CursorKind.FOR_STMT, CursorKind.WHILE_STMT, CursorKind.DO_STMT]:
                if niveau == 0:
                    compteur["simple"] += 1
                elif niveau == 1:
                    compteur["double"] += 1
                elif niveau == 2:
                    compteur["triple"] += 1
                compter_boucles(enfant, niveau + 1, compteur)
            else:
                compter_boucles(enfant, niveau, compteur)

        return compteur
    
    def compter_tests_et_else(node):
        tests = 0
        else_count = 0
        for enfant in node.get_children():
            if enfant.kind == CursorKind.IF_STMT:
                tests += 1
                has_else = False
                for sous_enfant in enfant.get_children():
                    if sous_enfant.kind == CursorKind.COMPOUND_STMT:
                        has_else = True
                if has_else:
                    else_count += 1
            tests_enfant, else_enfant = compter_tests_et_else(enfant)
            tests += tests_enfant
            else_count += else_enfant
        return tests, else_count
    
    def compter_appels_de_fonctions(node, nom_fonction):
        appels_librairies = 0
        appels_locales = 0
        appels_recursifs = 0
        
        for enfant in node.get_children():
            if enfant.kind == CursorKind.CALL_EXPR:
                if enfant.referenced and enfant.referenced.location and enfant.referenced.location.file:
                    if enfant.referenced.location.file.name == filepath:
                        appels_locales += 1
                        if enfant.spelling == nom_fonction:
                            appels_recursifs += 1
                    else:
                        appels_librairies += 1
            sous_resultat = compter_appels_de_fonctions(enfant, nom_fonction)
            appels_librairies += sous_resultat[0]
            appels_locales += sous_resultat[1]
            appels_recursifs += sous_resultat[2]
        
        return appels_librairies, appels_locales, appels_recursifs

    def compter_pointeurs(node):
        """
        Identifie les pointeurs utilisés dans la fonction (paramètres, variables locales et usages de pointeurs).
        """
        pointeurs_utilises = set()
        
        for enfant in node.get_children():
            # Compte les pointeurs déclarés comme paramètres ou variables locales
            if enfant.kind in [CursorKind.PARM_DECL, CursorKind.VAR_DECL] and enfant.type.kind == TypeKind.POINTER:
                pointeurs_utilises.add(enfant.spelling)
                
            # Compte l'utilisation des pointeurs dans des expressions (déférencement, accès via -> ou [])
            if enfant.kind == CursorKind.UNARY_OPERATOR and enfant.spelling == '*':
                pointeurs_utilises.add(enfant.spelling)
            if enfant.kind == CursorKind.MEMBER_REF_EXPR and '->' in enfant.displayname:
                pointeurs_utilises.add(enfant.spelling)
            if enfant.kind == CursorKind.ARRAY_SUBSCRIPT_EXPR:
                pointeurs_utilises.add(enfant.spelling)
                
            # Parcourt les enfants
            pointeurs_utilises.update(compter_pointeurs(enfant))
        
        return list(pointeurs_utilises)

    def compter_structures(node):
        """
        Identifie les structures utilisées dans la fonction.
        """
        structures_utilisees = set()
        
        for enfant in node.get_children():
            # Détection des structures passées en paramètre ou déclarées dans la fonction
            if enfant.kind in [CursorKind.PARM_DECL, CursorKind.VAR_DECL] and enfant.type.kind == TypeKind.RECORD:
                nom_structure = enfant.type.spelling
                structures_utilisees.add(nom_structure)
            
            # Accès à un champ de structure via le point (.) ou la flèche (->)
            if enfant.kind == CursorKind.MEMBER_REF_EXPR:
                structure_name = enfant.type.spelling
                structures_utilisees.add(structure_name)
                
            # Parcourt les enfants
            structures_utilisees.update(compter_structures(enfant))
        
        return list(structures_utilisees)
    
    def compter_variables(node):
        variables = set()
        for enfant in node.get_children():
            if enfant.kind == CursorKind.VAR_DECL:
                variables.add(enfant.spelling)
        return len(variables)

    def compter_attributs(node):
        attributs = set()
        for enfant in node.get_children():
            if enfant.kind == CursorKind.FIELD_DECL:
                attributs.add(enfant.spelling)
        return len(attributs)
    
    def compter_returns(node):
        compteur = 0
        for enfant in node.get_children():
            if enfant.kind == CursorKind.RETURN_STMT:
                compteur += 1
            compteur += compter_returns(enfant)
        return compteur

    def compter_complexite_cyclomatique(node):
        compteur = 1  # Initialisation
        for enfant in node.get_children():
            if enfant.kind in [CursorKind.IF_STMT, CursorKind.FOR_STMT, CursorKind.WHILE_STMT, CursorKind.CASE_STMT, CursorKind.DEFAULT_STMT]:
                compteur += 1
            compteur += compter_complexite_cyclomatique(enfant) - 1
        return compteur

    def verifier_macros(node):
        """
        Vérifie si des macros sont utilisées dans la fonction.
        """
        for enfant in node.get_children():
            if enfant.kind in [CursorKind.MACRO_INSTANTIATION, CursorKind.MACRO_DEFINITION]:
                return True
            if verifier_macros(enfant):
                return True
        return False
    
    for enfant in tu.cursor.get_children():
        if enfant.kind == CursorKind.FUNCTION_DECL and enfant.location.file and enfant.location.file.name == filepath:
            type_retour = enfant.result_type.spelling
            nombre_parametres = sum(1 for param in enfant.get_children() if param.kind == CursorKind.PARM_DECL)
            nombre_lignes = enfant.extent.end.line - enfant.extent.start.line + 1
        
            # Boucles
            compteur_boucles = compter_boucles(enfant)
        
            # Tests et else
            nombre_tests, nombre_else = compter_tests_et_else(enfant)
        
            # Appels de fonctions
            appels_librairies, appels_locales, appels_recursifs = compter_appels_de_fonctions(enfant, enfant.spelling)
        
            # Complexité cyclomatique
            complexite_cyclomatique = compter_complexite_cyclomatique(enfant)
        
            # Macros
            presence_macro = verifier_macros(enfant)
        
            # Pointeurs et structures
            pointeurs_utilises = compter_pointeurs(enfant)
            structures_utilisees = compter_structures(enfant)
        
            # Variables et attributs
            nombre_variables = compter_variables(enfant)
            nombre_attributs = compter_attributs(enfant)
            nombre_returns = compter_returns(enfant)
            
            resultats[enfant.spelling] = {
                "type_retour": type_retour,
                "nombre_parametres": nombre_parametres,
                "nombre_lignes": nombre_lignes,
                "nombre_boucles_simples": compteur_boucles["simple"],
                "nombre_boucles_doubles": compteur_boucles["double"],
                "nombre_boucles_triples": compteur_boucles["triple"],
                "nombre_pointeurs": len(pointeurs_utilises),
                "nombre_structures": len(structures_utilisees),
                "nombre_variables": nombre_variables,
                "nombre_attributs": nombre_attributs,
                "nombre_tests": nombre_tests,
                "nombre_else": nombre_else,
                "nombre_returns": nombre_returns,
                "appels_librairies": appels_librairies,
                "appels_locales": appels_locales,
                "appels_recursifs": appels_recursifs,
                "complexite_cyclomatique": complexite_cyclomatique,
                "presence_macro": presence_macro
            }

    return resultats


def analyser_base_de_donnees(db_path, table_name, output_csv):
    """
    Analyse une base de données contenant du code C et génère un fichier CSV avec les métriques.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(f"SELECT function_name, code FROM {table_name}")
    fonctions = cursor.fetchall()
    conn.close()
    
    file_exists = os.path.exists(output_csv)
    
    with open(output_csv, mode='a', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        
        if not file_exists:
            writer.writerow([
                "Fonction", "Type de retour", "Nombre de paramètres", "Nombre de lignes",
                "Nombre de boucles simples", "Nombre de boucles doubles", "Nombre de boucles triples",
                "Nombre de pointeurs", "Nombre de structures", "Nombre de variables",
                "Nombre attributs", "Nombre de tests", "Nombre de else", "Nombre de returns",
                "Nombre appels librairies", "Nombre appels locales", "Nombre appels récursifs",
                "Complexité cyclomatique", "Présence de macro"
            ])
        
        for nom_fonction, code_fonction in tqdm(fonctions, desc="Analyse en cours", unit="fonction"):
            with tempfile.NamedTemporaryFile(suffix=".c", delete=False) as temp_c_file:
                temp_c_file.write(code_fonction.encode('utf-8'))
                temp_c_file_path = temp_c_file.name
            
            try:
                resultats = analyse_code_c(temp_c_file_path)
                
                if nom_fonction in resultats:
                    stats = resultats[nom_fonction]
                    writer.writerow([
                        nom_fonction, stats["type_retour"], stats["nombre_parametres"],
                        stats["nombre_lignes"], stats["nombre_boucles_simples"],
                        stats["nombre_boucles_doubles"], stats["nombre_boucles_triples"],
                        stats["nombre_pointeurs"], stats["nombre_structures"],
                        stats["nombre_variables"], stats["nombre_attributs"],
                        stats["nombre_tests"], stats["nombre_else"],
                        stats["nombre_returns"], stats["appels_librairies"],
                        stats["appels_locales"], stats["appels_recursifs"],
                        stats["complexite_cyclomatique"], int(stats["presence_macro"])
                    ])
            finally:
                os.remove(temp_c_file_path)


# Exemple d'utilisation
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyse un fichier C ou une base de données et génère un fichier CSV des métriques.")
    parser.add_argument("--input_file", help="Chemin vers le fichier C à analyser", default=None)
    parser.add_argument("--db_path", help="Chemin vers la base de données SQLite", default=None)
    parser.add_argument("--table_name", help="Nom de la table contenant le code C", default=None)
    parser.add_argument("output_csv", help="Chemin vers le fichier CSV de sortie")
    args = parser.parse_args()
    
    if args.input_file:
        fonctions_analysees = analyse_code_c(args.input_file)
        file_exists = os.path.exists(args.output_csv)
        
        with open(args.output_csv, mode='a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            
            if not file_exists:
                writer.writerow([
                    "Fonction", "Type de retour", "Nombre de paramètres", "Nombre de lignes",
                    "Nombre de boucles simples", "Nombre de boucles doubles", "Nombre de boucles triples",
                    "Nombre de pointeurs", "Nombre de structures", "Nombre de variables",
                    "Nombre attributs", "Nombre de tests", "Nombre de else", "Nombre de returns",
                    "Nombre appels librairies", "Nombre appels locales", "Nombre appels récursifs",
                    "Complexité cyclomatique", "Présence de macro"
                ])
            
            for nom, stats in fonctions_analysees.items():
                writer.writerow([
                    nom, stats["type_retour"], stats["nombre_parametres"], stats["nombre_lignes"],
                    stats["nombre_boucles_simples"], stats["nombre_boucles_doubles"], stats["nombre_boucles_triples"],
                    stats["nombre_pointeurs"], stats["nombre_structures"], stats["nombre_variables"],
                    stats["nombre_attributs"], stats["nombre_tests"], stats["nombre_else"],
                    stats["nombre_returns"], stats["appels_librairies"], stats["appels_locales"],
                    stats["appels_recursifs"], stats["complexite_cyclomatique"], int(stats["presence_macro"])
                ])
    elif args.db_path and args.table_name:
        analyser_base_de_donnees(args.db_path, args.table_name, args.output_csv)
    else:
        print("Erreur : Veuillez spécifier soit un fichier C (--input_file) soit une base de données (--db_path et --table_name).")
    
    print(f"Analyse terminée. Résultats enregistrés dans {args.output_csv}.")
