// 1. Recherche du maximum - Récursive

int max_rec(int tab[], int n) { 
    if (n == 1)
        return tab[0];
    int max_suivant = max_rec(tab, n - 1);
    return (tab[n-1] > max_suivant) ? tab[n-1] : max_suivant;
}

// 2. Recherche du maximum - Itérative (boucle for)


int max_for(int tab[], int n) {
    int max = tab[0];
    for (int i = 1; i < n; i++) {
        if (tab[i] > max)
            max = tab[i];
    }
    return max;
}



// 3. Recherche du maximum - Diviser pour régner

int max_div_conq(int tab[], int gauche, int droite) {
    if (gauche == droite)
        return tab[gauche];
    int milieu = (gauche + droite) / 2;
    int max_gauche = max_div_conq(tab, gauche, milieu);
    int max_droite = max_div_conq(tab, milieu + 1, droite);
    return (max_gauche > max_droite) ? max_gauche : max_droite;
}



// 4. Recherche classique (parcours linéaire)

int rechercheLineaire(int arr[], int taille, int cible) {
    for (int i = 0; i < taille; i++) {
        if (arr[i] == cible) {
            return i;
        }
    }
    return -1;
}


// 5. Recherche du maximum - Pointeurs

int max_ptr(int *tab, int n) {
    int max = *tab;
    for (int *ptr = tab + 1; ptr < tab + n; ptr++) {
        if (*ptr > max)
            max = *ptr;
    }
    return max;
}

// 6. Recherche du maximum - Boucle while

int max_while(int tab[], int n) {
    int max = tab[0], i = 1;
    while (i < n) {
        if (tab[i] > max)
            max = tab[i];
        i++;
    }
    return max;
}


// 7. Recherche linéaire optimisé

int rechercheOptimisee(int arr[], int taille, int cible) {
    int i = 0;
    while (i < taille && arr[i] != cible) {
        i++;
    }
    return (i < taille) ? i : -1;
}


// 7. Recherche du maximum - Réduction

int max_via_reduction(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            arr[i + 1] = arr[i];
        }
    }
    return arr[n - 1];
}



// 8. Recherche du maximum - Recherche binaire

int max_via_recherche_binaire(int arr[], int debut, int fin) {
    if (debut == fin) 
        return arr[debut];
    if (arr[debut] > arr[fin]) 
        return arr[debut];
    return arr[fin];
}

// 9. Recherche du maximum - Approche de l'échange

int max_via_echange(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            int temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;
        }
    }
    return arr[n - 1];
}

// 10. Recherche du maximum - Utilisation d'une file (Queue)

typedef struct {
    int *data;
    int front, rear, size;
    int capacity;
} Queue;

Queue *creer_queue(int capacity) {
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->capacity = capacity;
    queue->front = queue->size = 0;
    queue->rear = capacity - 1;
    queue->data = (int *)malloc(queue->capacity * sizeof(int));
    return queue;
}

void enqueue(Queue *queue, int item) {
    queue->rear = (queue->rear + 1) % queue->capacity;
    queue->data[queue->rear] = item;
    queue->size = queue->size + 1;
}



int dequeue(Queue *queue) {
    int item = queue->data[queue->front];
    queue->front = (queue->front + 1) % queue->capacity;
    queue->size = queue->size - 1;
    return item;
}

int max_via_queue(int arr[], int n) {
    Queue *queue = creer_queue(n);
    for (int i = 0; i < n; i++) {
        enqueue(queue, arr[i]);
    }
    int max = dequeue(queue);
    while (queue->size > 0) {
        int val = dequeue(queue);
        if (val > max) {
            max = val;
        }
    }
    return max;
}