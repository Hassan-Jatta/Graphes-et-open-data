#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX 100

// 1. Listes chaînées : Définition de la structure
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// 2. Insertion en tête dans une liste chaînée
void insertAtHead(Node** head, int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// 3. Inversion d'une liste chaînée
void reverseList(Node** head) {
    Node *prev = NULL, *curr = *head, *next = NULL;
    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    *head = prev;
}

// 4. Détection de boucle (Algorithme de Floyd)
bool hasCycle(Node* head) {
    Node *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    return false;
}

// 5. Pile : Définition et initialisation
typedef struct Stack {
    int arr[MAX];
    int top;
} Stack;

void initStack(Stack* stack) {
    stack->top = -1;
}

// 6. Empiler un élément dans une pile
void push(Stack* stack, int data) {
    if (stack->top < MAX - 1) stack->arr[++stack->top] = data;
}

// 7. Conversion Infixée -> Postfixée
int precedence(char c) {
    if (c == '+' || c == '-') return 1;
    if (c == '*' || c == '/') return 2;
    return 0;
}

void infixToPostfix(char* infix, char* postfix) {
    Stack stack;
    initStack(&stack);
    int j = 0;
    
    for (int i = 0; infix[i] != '\0'; i++) {
        char c = infix[i];
        if (c == ' ') continue;
        if (c >= '0' && c <= '9') {
            postfix[j++] = c;
        } else if (c == '(') {
            push(&stack, c);
        } else if (c == ')') {
            while (stack.arr[stack.top] != '(') {
                postfix[j++] = stack.arr[stack.top--];
            }
            stack.top--;
        } else {
            while (stack.top != -1 && precedence(stack.arr[stack.top]) >= precedence(c)) {
                postfix[j++] = stack.arr[stack.top--];
            }
            push(&stack, c);
        }
    }
    while (stack.top != -1) {
        postfix[j++] = stack.arr[stack.top--];
    }
    postfix[j] = '\0';
}

// 8. Évaluation d'une expression postfixée
int evaluatePostfix(char* postfix) {
    Stack stack;
    initStack(&stack);
    for (int i = 0; postfix[i] != '\0'; i++) {
        char c = postfix[i];
        if (c >= '0' && c <= '9') {
            push(&stack, c - '0');
        } else {
            int b = stack.arr[stack.top--];
            int a = stack.arr[stack.top--];
            if (c == '+') push(&stack, a + b);
            if (c == '-') push(&stack, a - b);
            if (c == '*') push(&stack, a * b);
            if (c == '/') push(&stack, a / b);
        }
    }
    return stack.arr[stack.top--];
}

// 9. File : Définition et initialisation
typedef struct Queue {
    int arr[MAX];
    int front, rear;
} Queue;

void initQueue(Queue* queue) {
    queue->front = queue->rear = -1;
}

// 10. Enfiler un élément dans une file
void enqueue(Queue* queue, int data) {
    if (queue->rear < MAX - 1) {
        if (queue->front == -1) queue->front = 0;
        queue->arr[++queue->rear] = data;
    }
}