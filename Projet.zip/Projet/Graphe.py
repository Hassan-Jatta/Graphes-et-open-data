import pandas as pd
import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import BallTree  # Importer BallTree
import numpy as np
from tqdm import tqdm

def community_layout(graph, partition, scale=3, seed=42):
    """Positionne les nœuds en regroupant ceux des mêmes communautés."""
    np.random.seed(seed)
    
    communities = {}
    for node, comm in partition.items():
        communities.setdefault(comm, []).append(node)
    
    pos = {}
    num_communities = len(communities)
    angles = np.linspace(0, 2 * np.pi, num_communities, endpoint=False)
    
    # Rayon pour espacer les communautés
    radius = scale * 2
    
    for i, (comm, nodes) in enumerate(communities.items()):
        # Position centrale de la communauté
        center = np.array([np.cos(angles[i]) * radius, np.sin(angles[i]) * radius])
        
        # Placement des nœuds à l'intérieur du cluster
        subgraph = graph.subgraph(nodes)
        sub_pos = nx.spring_layout(subgraph, seed=seed)
        
        for node in nodes:
            pos[node] = sub_pos[node] + center  # Décalage vers le centre du cluster
    
    return pos

# Charger le fichier CSV
df = pd.read_csv('resultat.csv', sep=',')
df.columns = df.columns.str.strip()  # Nettoyer les noms de colonnes

# Sélectionner 230000 fonctions aléatoires
df_random = df.sample(n=230000, random_state=42).reset_index(drop=True)

# Normalisation des données numériques
tqdm.write("Normalisation des données...")
numerical_columns = df_random.columns[2:]  # Exclut 'Fonction' et 'Type de retour'
scaler = MinMaxScaler()
df_random[numerical_columns] = scaler.fit_transform(df_random[numerical_columns])

df_random.to_csv('resultats_normalises.csv', index=False)

# Création du graphe
G = nx.Graph()

# Ajouter les nœuds avec leurs attributs
for _, row in tqdm(df_random.iterrows(), total=len(df_random), desc="Ajout des nœuds"):
    G.add_node(row['Fonction'], **row.to_dict())

# Création du BallTree pour la recherche des voisins
features = df_random[numerical_columns].values
tree = BallTree(features, leaf_size=40)  # Créer le BallTree avec les caractéristiques normalisées

# Définir un seuil de distance pour l'ajout d'une arête
seuil_distance = 0.2  # Choisis un seuil de distance approprié entre 0 et 1

# Construction du graphe basé sur le seuil de distance
tqdm.write("Ajout des arêtes...")
edges_to_add = int(len(df_random) * (len(df_random) - 1) / 2)  # Nombre total d'arêtes possibles (sans doublons ni boucles)
with tqdm(total=edges_to_add, desc="Ajout des arêtes", unit="arête") as pbar:
    for i, row_i in df_random.iterrows():
        # Trouver les indices des voisins les plus proches à partir du BallTree
        distances, indices = tree.query([features[i]], k=len(df_random))  # Récupère tous les voisins
        for j in range(1, len(indices[0])):  # On commence à 1 pour éviter de lier un nœud avec lui-même
            j_index = indices[0][j]
            distance = distances[0][j]
            if distance < seuil_distance:
                row_j = df_random.iloc[j_index]
                weight = max(0.01, 1 - distance)  # Le poids de l'arête est inversément proportionnel à la distance
                G.add_edge(row_i['Fonction'], row_j['Fonction'], weight=weight)
            pbar.update(1)

# Vérifier la connexité et forcer la connexité si nécessaire
if not nx.is_connected(G):
    components = list(nx.connected_components(G))
    for i in range(len(components) - 1):
        node_a = list(components[i])[0]
        node_b = list(components[i+1])[0]
        G.add_edge(node_a, node_b, weight=0.1)

# Détection des communautés avec Louvain
partition = community_louvain.best_partition(G, resolution=1.5)

# Positionnement des nœuds
tqdm.write("Calcul du positionnement des nœuds...")
plt.figure(figsize=(12, 12))
pos = community_layout(G, partition)

# Palette de couleurs
palette = sns.color_palette("tab20", n_colors=len(set(partition.values())))

# Dessiner le graphe avec la coloration des communautés
nx.draw_networkx_nodes(G, pos, node_size=100, node_color=[palette[partition[node] % len(palette)] for node in G.nodes])
nx.draw_networkx_edges(G, pos, alpha=0.5, width=0.5)

plt.savefig('grapheBD_communautes.png', dpi=300, bbox_inches='tight')
plt.show()

# Sauvegarde des communautés dans un fichier
tqdm.write("Sauvegarde des communautés...")
communities = {}
for node, comm in partition.items():
    communities.setdefault(comm, []).append(node)

with open('communautesBD.txt', 'w', encoding='utf-8') as f:
    for comm, nodes in communities.items():
        f.write(f"Communauté {comm}: {', '.join(nodes)}\n")

print("Analyse terminée. Résultats enregistrés.")
