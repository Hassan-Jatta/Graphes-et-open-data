#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Plusieurs algorithmes sur les chaines de caractères

// 1. Vérification d'un palindrome
bool estPalindrome(char str[]) {
    int debut = 0;
    int fin = strlen(str) - 1;

    while (debut < fin) {
        if (str[debut] != str[fin]) {
            return false;
        }
        debut++;
        fin--;
    }
    return true;
}

// 2. Calcul de la longueur d'une chaîne (sans utiliser strlen)
int longueurChaine(char str[]) {
    int i = 0;
    while (str[i] != '\0') {
        i++;
    }
    return i;
}

// 3. Comparaison de chaînes (strcmp)
int comparaisonChaines(const char str1[], const char str2[]) {
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {
        if (str1[i] != str2[i]) {
            return 0; // Les chaînes sont différentes
        }
        i++;
    }
    return (str1[i] == str2[i]); // Retourner 1 si égales, 0 sinon
}

// 4. Recherche d'une sous-chaîne (Algorithme de Knuth-Morris-Pratt)
int rechercheSousChaineKMP(char texte[], char motif[]) {
    int n = strlen(texte);
    int m = strlen(motif);

    int lps[m]; // Tableau de préfixes de la chaîne motif
    int j = 0; // Index pour le motif

    // Calculer le tableau de préfixes (Longest Prefix Suffix)
    lps[0] = 0;
    int i = 1;
    while (i < m) {
        if (motif[i] == motif[j]) {
            j++;
            lps[i] = j;
            i++;
        } else {
            if (j != 0) {
                j = lps[j - 1];
            } else {
                lps[i] = 0;
                i++;
            }
        }
    }

    // Recherche du motif dans le texte
    i = 0; // Index pour le texte
    j = 0; // Index pour le motif
    while (i < n) {
        if (motif[j] == texte[i]) {
            i++;
            j++;
        }

        if (j == m) {
            return i - j; // Motif trouvé à l'index i - j
        } else if (i < n && motif[j] != texte[i]) {
            if (j != 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
    }
    return -1; // Motif non trouvé
}

// 5. Suppression des doublons dans une chaîne
void suppressionDoublons(char str[]) {
    int index = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        bool trouve = false;
        for (int j = 0; j < index; j++) {
            if (str[j] == str[i]) {
                trouve = true;
                break;
            }
        }
        if (!trouve) {
            str[index++] = str[i];
        }
    }
    str[index] = '\0'; // Ajouter le caractère de fin de chaîne
}

// 6. Concaténation de chaînes (sans utiliser strcat)
void concatenationChaines(char destination[], const char source[]) {
    int i = 0;
    while (destination[i] != '\0') {
        i++;
    }
    int j = 0;
    while (source[j] != '\0') {
        destination[i++] = source[j++];
    }
    destination[i] = '\0'; // Ajouter le caractère de fin de chaîne
}
